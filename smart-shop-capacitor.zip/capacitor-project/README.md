# تحويل "المحل الذكي" لتطبيق أندرويد حقيقي (APK)

## الملفات الموجودة في المشروع ده
- `package.json` — بيانات المشروع والمكتبات المطلوبة
- `capacitor.config.json` — إعدادات التطبيق (الاسم، الآيدي)
- `www/index.html` — تطبيقك بالكامل (نفس الملف اللي كنا بنشتغل عليه)

---

## الخطوات (لازم تتنفذ على كمبيوتر، مش موبايل)

### 1) تثبيت الأدوات (مرة واحدة بس)
- نزّل ونصّب **Node.js**: https://nodejs.org (اختار نسخة LTS)
- نزّل ونصّب **Android Studio**: https://developer.android.com/studio

### 2) افتح Terminal / Command Prompt جوه فولدر المشروع ده وشغّل:
```bash
npm install
```

### 3) ضيف منصة أندرويد:
```bash
npx cap add android
npx cap sync
```

### 4) افتح المشروع في Android Studio:
```bash
npx cap open android
```
(هيفتح Android Studio أوتوماتيك على مشروع الأندرويد)

### 5) من جوه Android Studio:
- استنى لحد ما يخلص "Gradle Sync" (شريط تحميل فوق)
- من القائمة: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
- هيديك رسالة فيها رابط "locate" — دوس عليه يوديك لمكان ملف الـ APK
- الملف هيكون هنا تقريبًا: `android/app/build/outputs/apk/debug/app-debug.apk`

### 6) انقل الـ APK لموبايلك وثبته
- ابعته لنفسك (واتساب، درايف، أي حاجة)
- فعّل "السماح بالتثبيت من مصادر غير معروفة" من إعدادات الموبايل
- افتح الملف ونزّله

---

## ⚠️ مهم: تفعيل صلاحية قراءة الملفات (Filesystem)

عشان ميزة "التحميل التلقائي من الجهاز" (`prices.json` و `sales.json`) تشتغل، لازم بعد `npx cap add android`، تروح للملف ده:
```
android/app/src/main/AndroidManifest.xml
```
وتتأكد إن السطرين دول موجودين جوه `<manifest>` (فوق `<application>`):
```xml
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
```

---

## بديل من غير Android Studio (أسهل) — GitHub + Codemagic

### 1) اعمل حساب على GitHub (لو مش عندك)
- روح على [github.com/signup](https://github.com/signup) واعمل حساب مجاني

### 2) ارفع المشروع على GitHub (من غير أوامر Git خالص)
- من صفحة GitHub الرئيسية دوس **"New repository"**
- اكتب اسم زي `smart-shop-app` واختار **Public** أو **Private** (مفيش فرق) ودوس **Create repository**
- في الصفحة اللي هتفتح، دوس **"uploading an existing file"**
- اسحب كل ملفات المشروع ده (package.json, capacitor.config.json, codemagic.yaml, فولدر www بكل اللي فيه) وارفعهم، وبعدين دوس **Commit changes**

### 3) اعمل حساب على Codemagic واربطه
- روح على [codemagic.io](https://codemagic.io) ودوس **Sign up** (تقدر تسجل مباشرة بحساب الـ GitHub بتاعك)
- بعد الدخول، دوس **Add application**
- اختار **GitHub** كمصدر، وسيب له صلاحية الوصول لحساباتك
- اختار الـ repository اللي رفعته (`smart-shop-app`)
- Codemagic هيكتشف ملف `codemagic.yaml` اللي في المشروع تلقائي (جهزتهولك already) — دوس **Save** أو **Finish**

### 4) شغّل البناء
- من صفحة التطبيق، دوس **Start new build**
- اختار الـ workflow اسمه "Smart Shop Android Build"
- استنى شوية (بياخد من 5 لـ 15 دقيقة)
- لما يخلص، هتلاقي تحت "Artifacts" ملف APK جاهز للتحميل مباشرة

### 5) نزّل الـ APK على موبايلك وثبته
- زي ما شرحنا فوق: فعّل "مصادر غير معروفة" وثبت الملف

---


## ملاحظة
كل مرة تعدّل في `www/index.html`، لازم تشغّل الأمر ده تاني قبل ما تعمل بناء جديد:
```bash
npx cap sync
```
